### Hexlet tests and linter status:
[![Actions Status](https://github.com/zluuba/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zluuba/python-project-49/actions) <a href="https://codeclimate.com/github/zluuba/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8f30055514168a104cb1/maintainability" /></a> <a href="https://codeclimate.com/github/zluuba/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/8f30055514168a104cb1/test_coverage" /></a>

### How to install and play:
[![asciicast](https://asciinema.org/a/czXe8Qba7zYxDJugwpKTtRgMG.svg)](https://asciinema.org/a/czXe8Qba7zYxDJugwpKTtRgMG)
