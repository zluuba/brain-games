from brain_games.games.gcd_game import greatest_cd, welcome


def gcd():
    greatest_cd()


def main():
    welcome()
    gcd()


if __name__ == '__main__':
    main()
