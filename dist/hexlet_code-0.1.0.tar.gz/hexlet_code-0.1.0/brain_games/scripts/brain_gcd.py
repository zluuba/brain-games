from brain_games.games.gcd_game import *
from brain_games.games.body import *


def gcd():
    game_rule()
    greatest_cd()


def main():
    welcome_user()
    user_name()
    gcd()


if __name__ == '__main__':
    main()
