### Hexlet tests and linter status:
[![Actions Status](https://github.com/zluuba/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zluuba/python-project-49/actions) <a href="https://codeclimate.com/github/zluuba/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8f30055514168a104cb1/maintainability" /></a> <a href="https://codeclimate.com/github/zluuba/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/8f30055514168a104cb1/test_coverage" /></a>

## How to install and play

### Even Game:
[![asciicast](https://asciinema.org/a/czXe8Qba7zYxDJugwpKTtRgMG.svg)](https://asciinema.org/a/czXe8Qba7zYxDJugwpKTtRgMG)

### Calculator Game:
[![asciicast](https://asciinema.org/a/Py5H3qA1l6nt21vKvbyo8JB4s.svg)](https://asciinema.org/a/Py5H3qA1l6nt21vKvbyo8JB4s)

### GreatestCommonDivisor Game:
[![asciicast](https://asciinema.org/a/ycL4JyR4DCvFapuTOwaEMAhYu.svg)](https://asciinema.org/a/ycL4JyR4DCvFapuTOwaEMAhYu)
