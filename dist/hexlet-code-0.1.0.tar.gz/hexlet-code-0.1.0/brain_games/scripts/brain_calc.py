from brain_games.games.calc_game import calculator, welcome


def calc():
    calculator()


def main():
    welcome()
    calc()


if __name__ == '__main__':
    main()
