from brain_games.games.even_game import is_even_game


def is_even():
    is_even_game()


def main():
    is_even()


if __name__ == '__main__':
    main()
