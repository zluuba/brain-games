from brain_games.games.even_game import *
from brain_games.games.body import *


def is_even():
    game_rule()
    is_even_game()


def main():
    welcome_user()
    user_name()
    is_even()


if __name__ == '__main__':
    main()
